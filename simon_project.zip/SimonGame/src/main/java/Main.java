import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;



public class Main {
  public static void main(String[] args)

  {
    
    boolean run = true; // variable to control the loop
    int score = 0; // variable to keep track of the score
    List<Integer> sequence = new ArrayList<Integer>(); // Integer list to store the sequence of numbers
    while (run) {

      // Uses java.util.Random to generate a random number between 0           and 4.
      Random rand = new Random();
      int pick = rand.nextInt(4) + 1;

      // Constructs the buttons as objects
      Button farLeft = new Button();
      Button middleLeft = new Button();
      Button middleRight = new Button();
      Button farRight = new Button();

      // Creates a Button array with the buttons as elements
      Button[] buttons = { farLeft, middleLeft, middleRight, farRight };
      List<Integer> playerSequence = new ArrayList<Integer>(); //           Integer list to store the player's sequence

      
      printGame(buttons); // Print the 4 buttons
      sequence.add(pick); // Add the randomly generated number to the       sequence list

      //For loop that prints the sequence the buttons are pressed in
      for (int i = 0; i < sequence.size(); i++) {
        buttons[sequence.get(i) - 1].clicked = true;
        clearScreen();
        printGame(buttons);
        try {
          Thread.sleep(700);
        } catch (InterruptedException e) {
          Thread.currentThread().interrupt();
        }
        buttons[sequence.get(i) - 1].clicked = false;
        clearScreen();
        printGame(buttons);
        try {
          Thread.sleep(800);
        } catch (InterruptedException e) {
          Thread.currentThread().interrupt();
        }
      }

      // Asks the user to input their sequence using the Scanner               package
      Scanner in = new Scanner(System.in);
      System.out.print("Sequence? ");
      String playerTypedSequence = in.nextLine();

      for (int i = 0; i < playerTypedSequence.length(); i++)
        {
          char g = playerTypedSequence.charAt(i);
    
          int guess = Character.getNumericValue(g);
          playerSequence.add(guess);
        }
      
      
      boolean matches = match(sequence, playerSequence);
      

      
      if (matches) {
        score++;      
          
      } 
      else {
        System.out.println("Your Score: " + score);
        run = false;
         in.close();
      }
 
    }
      
  }

  public static void printGame(Button[] b) {
    for (int i = 0; i < b.length; i++) {
      b[i].display();
    }
    System.out.println("");
  }

  public static void clearScreen() {
    System.out.print("\033[H\033[2J");
    System.out.flush();
  }
  public static boolean match(List<Integer> s, List<Integer> pS)
  {
    
    for(int i = 0; i < s.size(); i++)
      {
        if(s.get(i) != pS.get(i))
        {
          return false;
        }
      }
    return true;
  }
  
}