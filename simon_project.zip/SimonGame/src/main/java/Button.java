public class Button {
  public boolean clicked = false;

  public void display() {
    if (clicked) {
      System.out.print("[x]");
    } else {
      System.out.print("[ ]");
    }
  }
  
}